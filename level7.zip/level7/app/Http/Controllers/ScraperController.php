<?php

namespace App\Http\Controllers;

use Goutte\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

include "simple_html_dom.php";

class ScraperController extends Controller
{
    public function scraper()
    {
        $html = file_get_html("https://www.worldometers.info/coronavirus/");
        $table_data_array = array();
        
        foreach ($html->find('#main_table_countries_today tr') as $e) {
            // format the results for displaying in admin table:
            $formatted = str_replace("                                 ", ", ", $e->plaintext);
            $this->putcontents($formatted);
        }
        $contents = Storage::get('scraper_results.txt');
        $contents_array = explode("\n", $contents);
        for($x = 25; $x < count($contents_array); $x++) {
            $temp_array = explode(", ", $contents_array[$x]);
            array_push($table_data_array, json_encode($temp_array));
        }
        return view('scraper', compact('table_data_array'));
        
    }

    private function putcontents($text)
    {
        try {
            Storage::disk('local')->append('scraper_results.txt', $text . "\n", null);
       } catch (\Exception $e) {
            dd($e);
       }
    }
}
